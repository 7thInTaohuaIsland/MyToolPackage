import cv2
import numpy as np
class ChannelSeparate:
    def __init__(self):
        self.pattern=[90,45,135,0]
    @property
    def pattern(self):
        return self.__pattern
    @pattern.setter
    def pattern(self,value):
        def __value_error():
            raise ValueError(
                "Value 'pattern' must be rearrangement of list [0,45,90,135] "
                "with list-length-4 and interger element.")
        def __whether_rearrange(list):
            for item in [90,45,135,0]:
                if item not in list:
                    __value_error()
                    break
        if len(value)!=4:
            __value_error()
        __whether_rearrange(value)
        self.__pattern=value
    def Separate(self,img)->dict:
        dict = {}
        y, x = img.shape
        [a,b,c,d]=self.__pattern
        dict[a] = img[0:y:2, 0:x:2]
        dict[b] = img[0:y:2, 1:x:2]
        dict[c] = img[1:y:2, 0:x:2]
        dict[d] = img[1:y:2, 1:x:2]
        return dict